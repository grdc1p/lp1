let numeros = [4, 11, 8, 15, 23, 7, 2];

let NumeroMaiorQue10 = 0;

numeros.forEach(numero => {

if (numero > 10) {

NumeroMaiorQue10++;}

});

console.log(NumeroMaiorQue10);
