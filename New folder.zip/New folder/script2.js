let nomes = ["João", "Maria", "Carlos", "Ana"];

let nomesComPrefixo = [];

nomes.forEach(nome => {
nomesComPrefixo.push(`Sr(a). ${nome}`);

});console.log(nomesComPrefixo);
