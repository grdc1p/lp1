let nomes = ["ana", "carlos", "maria"];

nomes.forEach((nome, index, arr) => {
    arr[index] = nome.toUpperCase();
});

console.log(nomes); 
